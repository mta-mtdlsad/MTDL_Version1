import React from 'react';
import '../../styles/App.css'

function TrackStatus({tracks = []}) {
    const activeCount = tracks.filter(
        track => track.trackStatus === 'ACTIVE'
    ).length;
    const inactiveCount = tracks.filter(
        track => track.trackStatus === 'INACTIVE'
    ).length;
    return (
        <section className="dashboard-panel">
            <h2>Track Status</h2>
            <div className="dashboard-row">
                <span className="track-status active">
                    ACTIVE
                </span>
                <strong>{activeCount}</strong>
            </div>
            <div className="dashboard-row">
                <span className="track-status inactive">
                    INACTIVE
                </span>
                <strong>{inactiveCount}</strong>
            </div>
        </section>
    );
}

export default TrackStatus;